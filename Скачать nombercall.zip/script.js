function generateCode() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}
function registerUser() {
  const name = document.getElementById("username").value;
  if (!name) return alert("Введите имя!");
  const code = generateCode();
  localStorage.setItem("userName", name);
  localStorage.setItem("userCode", code);
  alert(`Зарегистрирован: ${name}, код: ${code}`);
}
function searchCode() {
  const input = document.getElementById("searchCode").value;
  alert(`Ищем пользователя с кодом: ${input}`);
}
function setVoice(voiceType) {
  alert(`Голос изменён на: ${voiceType}`);
}
function shareSite() {
  if (navigator.share) {
    navigator.share({
      title: "NomberCall",
      text: "Залетай в NomberCall",
      url: window.location.href,
    });
  } else {
    alert("Добавь сайт вручную через браузер (иконка Поделиться → На экран домой)");
  }
}
const canvas = document.getElementById("bg");
const ctx = canvas.getContext("2d");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;
let particles = Array.from({ length: 50 }, () => ({
  x: Math.random() * canvas.width,
  y: Math.random() * canvas.height,
  r: Math.random() * 3 + 1,
  dx: Math.random() * 0.5 - 0.25,
  dy: Math.random() * 0.5 - 0.25,
}));
function animate() {
  ctx.fillStyle = "rgba(0, 0, 0, 0.3)";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = "#00bfff";
  for (let p of particles) {
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
    ctx.fill();
    p.x += p.dx;
    p.y += p.dy;
    if (p.x < 0 || p.x > canvas.width) p.dx *= -1;
    if (p.y < 0 || p.y > canvas.height) p.dy *= -1;
  }
  requestAnimationFrame(animate);
}
animate();
